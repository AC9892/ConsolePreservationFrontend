# CPF Nintendo DSi v0.1.0 alpha

This portable Windows x64 package was built from the accompanying clean public source archive. It keeps the existing DSi importer, desktop shell, and compatibility backend. The later Menu tile and Unlaunch probes are excluded.

This is an alpha. Read INSTALLATION.md and KNOWN_ISSUES.md before use. No Nintendo system data or user captures are included.
