# Rust package license files

These files came from the locally cached packages resolved for Windows x64. Six crates without bundled license files use reviewed source-revision overrides; see OVERRIDE_PROVENANCE.md. See the dependency inventory for package versions and declared license expressions. This collection does not decide the CPF project license or replace a final notices review.

Packages without a license-like file in their cached package root:


