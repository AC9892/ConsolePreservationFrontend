# Third-party notices

Pseudo Game Mounter uses Tauri and the Rust packages listed in DEPENDENCIES.md. Their license texts are in licenses/rust. The standalone melonDS executable and Nintendo console data are not bundled.
